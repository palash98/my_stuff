module.exports = require("./Widget.js");
module.exports["version"] = require("../../package.json").version;
