Captum.Utils
============

.. automodule:: captum.attr._utils.common

.. autofunction:: validate_input
.. autofunction:: validate_noise_tunnel_type
.. autofunction:: format_input
.. autofunction:: _format_attributions
.. autofunction:: zeros
.. autofunction:: _reshape_and_sum
.. autofunction:: _run_forward
