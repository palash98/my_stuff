Input X Gradient
===============

.. autoclass:: captum.attr.InputXGradient
    :members:
