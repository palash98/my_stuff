Captum.Models
==========================

.. automodule:: captum.attr._models.pytext

.. autoclass:: PyTextInterpretableEmbedding
    :members:


.. autoclass:: BaselineGenerator
    :members:
